package edu.depaul.se480;

/**
 * Class: SE<xxx> - <descrption>
 * Author: Raquib Talukder
 **/

public interface IUserService {
    int getAge();
    int execute() throws InterruptedException;
}
